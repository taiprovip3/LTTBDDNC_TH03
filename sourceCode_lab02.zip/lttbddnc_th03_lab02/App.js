//importing//
import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator, TransitionPresets } from '@react-navigation/stack';
import { Button } from 'react-native-paper';
//body//
const Stack = createStackNavigator();
function MyStack() {
  return (
    <Stack.Navigator screenOptions={TransitionPresets.ScaleFromCenterAndroid}>
      <Stack.Screen name="HomepageScreen" component={HomepageScreen} />
      <Stack.Screen name="HelloWorldScreen" component={HelloWorldScreen} />
      <Stack.Screen name="BackScreen" component={BackScreen} />
    </Stack.Navigator>
  );
}
function HomepageScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>This is the HomePage!</Text>
      <Button
        mode="contained"
        onPress={() => navigation.navigate('HelloWorldScreen')}
      >Go to HelloWorld</Button>
    </View>
  );
}
function HelloWorldScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text>This is HelloWorld screen!</Text>
      <Button onPress={() => navigation.goBack()} mode="outlined">Back</Button>
    </View>
  );
}
function BackScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Button
        title="Go to back previous screen."
        onPress={() => navigation.goBack()}
      />
    </View>
  );
}







export default function App() {
  return (
    <NavigationContainer>
      <MyStack />
    </NavigationContainer>
  );
}

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'center',
//     backgroundColor: '#ecf0f1',
//     padding: 8,
//   }
// });
