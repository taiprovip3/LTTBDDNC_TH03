import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
// import Constants from 'expo-constants';
import { Button, TextInput } from 'react-native-paper';
// import { NavigationContainer } from '@react-navigation/native';

export default function App({ navigation }) {

  const [numbera, setNumbera] = React.useState(0);
  const [numberb, setNumberb] = React.useState(0);
  const [total, setTotal] = React.useState(0);

  const mathPlus = () =>{
      const plus = parseFloat(numbera) + parseFloat(numberb);
      setTotal(plus);
  }

  return (
    <View style={styled.containerBox}>
        <View style={styled.containerView1}>
          <Text style={styled.textStyle}>Math:</Text>
            <TextInput
              label="Enter the number a..."
              value={numbera}
              onChangeText={numbera => setNumbera(numbera)}
            />
            <TextInput
              label="Enter the number b..."
              value={numberb}
              onChangeText={numberb => setNumberb(numberb)}
            />
            <Button icon="camera" mode="contained" onPress={() => mathPlus()}>
              +
            </Button>
            <Button icon={{ source: { uri: 'https://avatars0.githubusercontent.com/u/17571969?v=3&s=400' }, direction: 'rtl' }}
            mode="contained"
            >
              -
            </Button>
        </View>
        <View style={styled.containerView2}>
            <Text>Result:</Text>
            <TextInput
              label="Read only"
              mode="outlined"
              disabled="true"
              value={total}
              onChangeText={total => setTotal(total)}
            />
        </View>
        <View style={styled.containerView3}>
          <Button
            mode='outlined'
          >Go to page</Button>
        </View>
    </View>
  );
}

const styled = StyleSheet.create({
  containerBox: {
    flex: 1
  },
  containerView1: {
    flex: 1,
    backgroundColor: '#32a87d',
    padding: '25px',
    paddingBottom: '100px',
  },
  containerView2: {
    flex: 1,
    backgroundColor: '#dbd82a',
    padding: '20px',
  },
  containerView3: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textStyle: {
    color: 'white'
  }
});
